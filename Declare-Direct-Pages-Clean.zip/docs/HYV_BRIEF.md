# HyV Fuel Project Brief

## Brand
HyV Fuel by AyuVed Pvt Ltd.

## Domain
hyvfuel.in

## Core category
Performance Fuel Shot / Micro-Fueling System.

## Core tagline
Pure Power. One Squeeze.

## Product concept
A honey-based 30ml performance fuel shot for athletes, designed as an alternative to sugar-heavy energy drinks, artificial sweetener drinks, and maltodextrin-heavy gels.

## Packaging innovation
Hexopod: perfect hexagon sachet inspired by honeycomb.
Stinger: tiny outlet/spout.
One Shot Delivery System: squeeze from the opposite corner and push contents toward the Stinger until the pouch empties.

## Master front-pack hierarchy
Every Hexopod front follows the same order:
1. Official asymmetric honeycomb logo, centred near the top.
2. Product name in gold directly beneath the logo.
3. Functional state in the product variant colour.
4. A short ingredient line beneath the state.

### Variant system
- **HyV Fuel** — black + gold — **Activation** — Honey · Caffeine · Electrolytes
- **HyV Flow** — black + magenta — **Sustenance** — Honey · Himalayan Secret · Electrolytes
- **HyV Re-Fuel** — black + blue — **Restoration** — Honey · Creatine · Electrolytes · L-Theanine

All future packaging images must use this hierarchy and the official asymmetric honeycomb logo. Product names remain gold; only the state, trim and variant accents change colour.

## Product ecosystem
1. HyV Fuel — Activate — pre-workout
2. HyV Flow — Sustain — during workout/race day
3. HyV Re-Fuel — Restore — post-workout

## HyV Fuel front-pack ingredient message
Honey, caffeine, electrolytes.

## HyV Flow front-pack ingredient message
Honey, Himalayan Secret, electrolytes.

## HyV Re-Fuel front-pack ingredient message
Honey, creatine, electrolytes, L-theanine.

## Website goal
Launch a premium beta/waitlist landing page first.
Do not launch full checkout before manufacturing validation.

## Key CTAs
Join Beta
Explore Product
