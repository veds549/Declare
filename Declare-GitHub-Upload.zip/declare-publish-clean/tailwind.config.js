export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        hyvBlack: '#050505',
        hyvGold: '#F5B000',
        hyvBlue: '#1B5CFF',
        hyvCopper: '#D87A21',
      },
      fontFamily: {
        display: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
